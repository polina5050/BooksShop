﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kraynowa_Books
{
    class BDBooks
    {
        public static Entities EM;
    }
}
