﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kraynowa_Books
{
    /// <summary>
    /// Логика взаимодействия для PageBook.xaml
    /// </summary>
    public partial class PageBook : Page
    {
        List<Книги> BookList = BDBooks.EM.Книги.ToList();
        List<Авторы> AvtorsList = BDBooks.EM.Авторы.ToList();
        List<Книги> Books = new List<Книги>();
       
        public PageBook()
        {
            InitializeComponent();
            Books = BookList;
            DGBooks.ItemsSource = BDBooks.EM.Книги.ToList();
        }
        int i = -1;
        private void TextBlock_Initialized(object sender, EventArgs e)
        {
            if (i < Books.Count)
            {
                TextBlock TB = (TextBlock)sender;
                Книги S = Books[i];
                TB.Text = S.Название;

            }
        }

        private void TextBlock_Initialized_1(object sender, EventArgs e)
        {
            if (i < Books.Count)
            {
                TextBlock TA = (TextBlock)sender;
                Книги C = Books[i];
                TA.Text = Convert.ToString(C.Автор);

            }
        }

        private void TextBlock_Initialized_2(object sender, EventArgs e)
        {
            if (i < Books.Count)
            {
                TextBlock TA = (TextBlock)sender;
                Книги K = Books[i];
                TA.Text = Convert.ToString(K.Цена)+ " ";

            }
        }

        private void TextBlock_Initialized_3(object sender, EventArgs e)
        {
            if (i < Books.Count)
            {
                TextBlock TN = (TextBlock)sender;
                Книги N = Books[i];
                if (N.Количество_магазин > 5)
                {
                    TN.Text = "Много";
                }
                else {
                    TN.Text = Convert.ToString(N.Количество_магазин);
                }
            }
        }

        private void TextBlock_Initialized_4(object sender, EventArgs e)
        {
            if (i < Books.Count)
            {
                TextBlock TN = (TextBlock)sender;
                Книги N = Books[i];
                if (N.Количество_склад > 5)
                {
                    TN.Text = "Много";
                }
                else
                {
                    TN.Text = Convert.ToString(N.Количество_склад);
                }
                

            }

        }
        int col = 0;
        int SumPrice;
        int price;
        int sail;
        
        private void StackPanel_Initialized(object sender, EventArgs e)
        {
           
        }

        private void MediaElement_Initialized(object sender, EventArgs e)
        {
            if (i < Books.Count)
            {
                i++;
                MediaElement ME = (MediaElement)sender;
                Книги S = Books[i];
                Uri U = new Uri(S.Обложка, UriKind.RelativeOrAbsolute);
                ME.Source = U;
            }
        }
        int ind;
        /// <summary>
        /// кнопка покупки
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bye_Click(object sender, RoutedEventArgs e)
        {
            Button BtnRed = (Button)sender;
            
            Книги RD = BookList[ind];
            Книги SZn = BookList[ind];
            col += 1;
        }
        /// <summary>
        /// количество книг
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBlock_Initialized_5(object sender, EventArgs e)
        {
            TextBlock TB = (TextBlock)sender;
            TB.Text = Convert.ToString(col);
        }
        /// <summary>
        /// цена покупки
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBlock_Initialized_6(object sender, EventArgs e)
        {
            TextBlock TP = (TextBlock)sender;
            Книги RD = BookList[ind];
            Книги SZn = BookList[ind];
            TP.Text = Convert.ToString(SZn.Цена);
        }
        /// <summary>
        /// скидка
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBlock_Initialized_7(object sender, EventArgs e)
        {

        }
    }
}
